# FlowMe UX/UI Supplemental Screenshots

This package supplements the previous Claude Design review zip. The earlier set did not show enough saved-state evidence for My Flow and Calendar.

- Captured at: 2026-07-03T19:00:34.111Z
- Base URL: http://127.0.0.1:3104
- Viewport: 390 x 844
- Focus: moving map save, date-less math save, multiple saved content, calendar agenda/detail, bottom spacing.

## Screenshot Index

1. `screenshots/01-moving-map-date-filled-before-save.png` - Moving map before save: Flow Map detail with the moving date filled before saving.
2. `screenshots/02-moving-post-save-my-flow-top.png` - Moving post-save My Flow top: Immediately after saving moving-d30, showing the saved banner and first executable task.
3. `screenshots/03-moving-post-save-first-task-open.png` - Moving first task opened: Post-save first task opened in My Flow, with detail and checklist content visible.
4. `screenshots/04-moving-my-flow-saved-content-list.png` - Moving saved content list: My Flow saved-content view after saving moving-d30.
5. `screenshots/05-moving-my-flow-bottom-spacing.png` - Moving My Flow bottom spacing: Bottom of My Flow after saving, showing content clears the fixed mobile tabs.
6. `screenshots/06-moving-calendar-agenda-top.png` - Calendar after save: agenda top: Calendar route after saving, with the selected-day agenda visible.
7. `screenshots/06-moving-calendar-month-grid.png` - Calendar after save: month grid: Month grid and schedule markers after saved rows are available.
8. `screenshots/06-moving-calendar-agenda-detail-open.png` - Calendar after save: selected item detail: Selected agenda row opened to show task detail, memo/source/export access area.
9. `screenshots/06-moving-calendar-bottom-spacing.png` - Calendar bottom spacing: Bottom of Calendar route to show content is not hidden by the fixed mobile tabs.
10. `screenshots/10-math-map-before-save.png` - Math map before save: Date-less math source-backed map before saving.
11. `screenshots/11-math-post-save-my-flow-top.png` - Math post-save My Flow top: Date-less content saved into My Flow, showing a first executable fallback instead of an empty state.
12. `screenshots/12-math-post-save-first-task-open.png` - Math first task opened: Date-less saved content with its first study task opened.
13. `screenshots/13-math-my-flow-saved-content-list.png` - Math saved content list: My Flow saved-content view for the date-less math map.
14. `screenshots/14-multiple-saved-my-flow-top.png` - Multiple saved: My Flow top: My Flow normal entry with moving and math content both saved.
15. `screenshots/15-multiple-saved-content-list.png` - Multiple saved: content list: Saved-content list showing more than one saved content card.
16. `screenshots/16-multiple-calendar-agenda-top.png` - Calendar after save: agenda top: Calendar route after saving, with the selected-day agenda visible.
17. `screenshots/16-multiple-calendar-month-grid.png` - Calendar after save: month grid: Month grid and schedule markers after saved rows are available.
18. `screenshots/16-multiple-calendar-agenda-detail-open.png` - Calendar after save: selected item detail: Selected agenda row opened to show task detail, memo/source/export access area.
19. `screenshots/16-multiple-calendar-bottom-spacing.png` - Calendar bottom spacing: Bottom of Calendar route to show content is not hidden by the fixed mobile tabs.
20. `screenshots/20-public-flow-before-save.png` - Public Flow before save: Public Flow detail with app shell and save action visible.

## How To Review

Open `index.html` first. It shows every screenshot with the route URL and the reason the frame was captured.
Use `manifest.json` if you need route, title, and text sample metadata.
