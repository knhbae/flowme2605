# Validation Fix Batch — Delivery (2026-05-26)

이 폴더는 `docs/validation-sessions/TESTABLE_CONTENT.md`의 11개 라우트를 첫 observed-session 직전 상태로 정합화하기 위한 **감사 + 구현 스펙 + visual reference**다.

## 파일 구조

```
docs/
├── content-audit/
│   ├── 2026-05-26-validation-routes-ux-review.md      ← 감사 보고서 (왜 고치는가)
│   └── 2026-05-26-validation-fix-implementation.md    ← 구현 스펙 (PR-1~10)
└── design-ref/
    └── 2026-05-26-validation-fix/
        ├── flowme.html                                ← 인터랙티브 Before/After 캔버스
        ├── *.jsx, styles.css                          ← 위 html이 로드하는 컴포넌트
        └── README.md                                  ← 캔버스 여는 법
```

## 깃헙 repo로 옮길 때

이 `delivery/` 폴더 자체를 옮기는 게 아니라, 안쪽 `docs/` 폴더의 구조 그대로 기존 `knhbae/flowme2605` repo의 `docs/`와 머지하면 됩니다:

```bash
# repo 루트에서
cp -r delivery/docs/content-audit/2026-05-26-* docs/content-audit/
cp -r delivery/docs/design-ref/2026-05-26-validation-fix docs/design-ref/
```

그러면:
- `docs/content-audit/`에는 기존 30+개 audit 파일과 같은 패턴으로 두 개의 .md가 추가됨
- `docs/design-ref/`에는 인터랙티브 Before/After 캔버스가 추가됨

커밋 메시지 예시:

```
docs(content-audit): add validation routes UX review + implementation spec

- 11 routes from TESTABLE_CONTENT.md audited against design.md principles
- 10 PRs scoped: schema fields + UI components + seed text adjustments
- Before/After interactive canvas added to docs/design-ref/

Refs: docs/validation-sessions/TESTABLE_CONTENT.md
```

## 어디서부터 읽으면 좋은가

### 코드를 짤 사람
1. **`docs/content-audit/2026-05-26-validation-fix-implementation.md`** — PR-1부터 시작. 파일 경로, schema diff, 카피 strings, 머지 순서가 다 있음.
2. 막히는 부분이 있으면 같은 폴더의 `validation-routes-ux-review.md`로 “왜”를 다시 확인.
3. 모양이 헷갈리면 `docs/design-ref/2026-05-26-validation-fix/flowme.html`을 브라우저로 열어 해당 BEFORE/AFTER 아트보드를 직접 비교.

### 리뷰할 사람 / observed session 진행할 사람
1. **`docs/content-audit/2026-05-26-validation-routes-ux-review.md`** — 11개 라우트 전체 검토. 어떤 라우트가 어떤 위험을 갖고 있는지.
2. 그 안의 **A1~A6 cross-cutting 문제 6개**와 **C 섹션의 즉시 적용 가능한 작은 PR 5개**가 우선순위 결정용.

## Observed session 시작 전 머지 목표

`implementation-spec.md`의 머지 순서 기준:
- ✅ **PR-1** (seed text 정합화) — 코드 변경 없음, 가장 안전
- ✅ **PR-2** (anchor 라벨 필드) — 첫 화면 의도 명시
- ✅ **PR-3** (sticky CTA 동적) — 모바일 첫 행동에 직접 영향
- ✅ **PR-4** (stop_conditions / principles) — diet 라우트 핵심

PR-5 ~ PR-10은 첫 session 결과 보고 머지.

## 절대 변경하지 않을 것

- `validated` / `검증됨` 라벨 추가 금지 — `candidate signal`까지만.
- 전역 sticky export bar 신설 금지.
- 사용자 가입·로그인·결제·AI 자동 큐레이션·전역 progress bar 금지.
- health-sensitive 라우트에서 outcome 문구 추가 금지.
- money-at-risk 라우트에서 사인 결정 명령 금지.

자세한 내용은 [`implementation-spec.md`](./docs/content-audit/2026-05-26-validation-fix-implementation.md)의 마지막 섹션 참고.
