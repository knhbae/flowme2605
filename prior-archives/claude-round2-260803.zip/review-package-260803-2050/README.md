# Claude 디자인 2차 근본 UX 검토 · FlowMe P35

- 작성: 2026-08-03 · 검토자 Claude Design (2차 독립 UX/IA 검토)
- 대상: FlowMe P35 (공개 상세 → 편집 → 저장 → 내 계획 → 실행/내보내기)
- 판정: **revise** (structural_reopen 아님, retain 아님)
- observed_user: **0** — 이 검토는 디자인 전문가의 내부 시뮬레이션이며 실제 사용자 관찰이 아니다.

## 한 줄 결론

P35의 근본 문제는 색상·간격·아이콘이 아니라 **상태 소유권**이다. 공개 상세(아직 내 것이 아닌 초안)와 저장된 계획(내 것)이 같은 카드·같은 버튼·같은 "가져가기" 블록을 공유하면서, 사용자는 "지금 무엇이 만들어졌고, 어디에 남았고, 무엇을 옮기는 중인가"를 화면에서 읽을 수 없다.

## 파일 목록

| 파일 | 내용 |
| --- | --- |
| 01-root-findings-ko.md | 근본 문제 5개와 증거, 5초 이해·상태 지도 |
| 02-lifecycle-and-ownership-ko.md | 상태 지도, 저장/내보내기 소유권 대안 3안 |
| 03-my-flow-ia-options-ko.md | 내 계획 IA 3안 비교와 권장안 |
| 04-editor-and-projection-system-ko.md | 공통 editor family, 결과 형식 capability 규칙 |
| 05-copy-and-disclosure-ko.md | 용어·CTA 라벨, 도움말 4등급, layer 규칙 |
| 06-screen-spec-ko.md | 화면별 정보 순서·행동·상태·예외 (P1–P8, D1–D2) |
| 07-scorecard-ko.md | 공통 판정 축 채점본 |
| wireframes/ | 제안 화면 보드 위치 안내 |

## 제안 화면(wireframes)

390×844 여덟 화면 + 1440 두 화면은 저장소 루트의
**"FlowMe P35 2차 근본 UX 검토.dc.html"** 한 파일에 Before(현재 캡처 원본)와
Proposal을 나란히 담았다. 브라우저에서 그대로 열린다.

## 근거와 접근하지 못한 자료

- 근거: 현재 P35 캡처 14개(390/1024) + push된 handoff 문서(review-brief-ko.md, README.md, screenshot-manifest.json, claude-design-review-prompt-ko.txt).
- **접근 못함**: 요청서가 지목한 2026-08-03 폴더(01-owner-feedback-normalized-ko.md ~ 08-review-scorecard-ko.md, 03-current-state-evidence-map-ko.md, 이전 Before/After 보고서)는 저장소에 push되어 있지 않다.
- **의도적으로 보지 않음**: 같은 라운드 다른 검토자의 결론 문서 — 독립성 유지.
- 구현되지 않은 제안은 After가 아니라 **Proposal**로 표기했다.

## 표기 규칙

- 근거: 현재 캡처·문서에서 직접 읽은 것
- 설계 추론: 자료에 없어 UX 원리로 메운 것
- 확인 필요: 로컬 동작·데이터로만 확인 가능한 것
- 권장 / 기각: 최종 제안과 쓰지 않을 안
